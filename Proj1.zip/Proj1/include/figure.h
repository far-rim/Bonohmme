#include <iostream>
#include <graphics.h>
#ifndef FIGURE_H
#define FIGURE_H
using namespace std;

class figure
{
    public:
        int type,x,y,a,b,c;
        figure(){}

        void set_droite(int x, int y,int a,int b, int c){ //declarer droite.
            this->c=c;
            this->x=x;
            this->y=y;
            this->a=a;
            this->b=b;

            if(a>0 && b==0)
                this->type = 1;
            else if(a==0 && b>0)
                this->type = 2;
            else if(a>0 && b!=0)
                this->type = 3;
            else
                cout << "Les mesures sont erron�es";
        }
        void set_cercle(int x, int y,int a, int c){ //declarer cercle.
            this->c=c;
            this->x=x;
            this->y=y;
            this->a=a;
            if(a>0)
                this->type = 4;
            else
                cout <<"Le diam�tre ne peut pas �tre n�gatif";
        }
        void set_rectangle(int x, int y,int a,int b, int c){ //declarer rectangle.
            this->c=c;
            this->x=x;
            this->y=y;
            this->a=a;
            this->b=b;
            if(a>0 && b>0)
                this->type = 5;
            else
                cout << "Les mesures sont erron�es";
        }
        void set_croix(int x, int y,int a,int b, int c){ //declarer croix.
            this->c=c;
            this->x=x;
            this->y=y;
            this->a=a;
            this->b=b;
            if(a>0 && b>0)
                this->type = 6;
            else
                cout << "Les mesures sont erron�es";
        }
        void set_triangle(int x, int y,int a,int b, int c){ //declarer triangle.
            this->c=c;
            this->x=x;
            this->y=y;
            this->a=a;
            this->b=b;
            if(a>0 && b>0)
                this->type = 7;
            else
                cout << "Les mesures sont erron�es";
        }
        int get_couleur(){ //return la couleur de la figure.
            return this->c;
        }
        int get_x_centre(){ //return l abscisse du centre.
            return this->x;
        }
        int get_y_centre(){ //return l ordonnee du centre .
            return this->y;
        }

        int get_x_min(){ //return x minimal.
            if(this->type==2)
                return this->x;

            else
                return (this->x)-(this->a/2);

        }
        int get_x_max(){ //return x maximal
            if(this->type==2)
                return this->x;
            else
                return (this->x)+(this->a/2);

        }
        int get_y_min(){ //return y minimal.
            if(this->type==1)
                return this->y;
            else if (this->type==7)
                return this->y-this->b*2/3;
            else
                return (this->y)-(this->b/2);

        }
        int get_y_max(){ //return y maximal.
            if(this->type==1)
                return this->y;
            else if (this->type==7)
                return this->y+this->b/3;
            else
                return (this->y)+(this->b/2);

        }
        void dessiner(){ //dessiner les figures selon le type.

            setcolor(this->c);
            switch(this->type){
            case 1:
                line(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
                break;
            case 2:
                line(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
                break;
            case 3:
                line(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
                break;
            case 4:
                circle(this->x,this->y,this->a/2);
                break;
            case 5:
                rectangle(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
                break;
            case 6:
                line(this->get_x_centre()-this->a/2,this->get_y_centre()-this->b/2, this->get_x_centre()+this->a/2,this->get_y_centre()+this->b/2);
                line(this->get_x_centre()-this->a/2,this->get_y_centre()+this->b/2, this->get_x_centre()+this->a/2,this->get_y_centre()-this->b/2);
                break;
            case 7:
                line(this->get_x_centre(),this->get_y_centre()-this->b*2/3, this->get_x_centre()-this->a/2,this->get_y_centre()+this->b/3);
                line(this->get_x_centre(),this->get_y_centre()-this->b*2/3, this->get_x_centre()+this->a/2,this->get_y_centre()+this->b/3);

                line(this->get_x_centre()-this->a/2,this->get_y_centre()+this->b/3, this->get_x_centre()+this->a/2,this->get_y_centre()+this->b/3);
                break;
            }

        }
        void deplacer(int dx, int dy){ //d�placer une figure de sa position initiale.
            int tempC=this->c;
            this->c=0;
            this->dessiner();

            this->x+=dx;
            this->y+=dy;
            this->c=tempC;
            this->dessiner();
        }

};

#endif // FIGURE_H
