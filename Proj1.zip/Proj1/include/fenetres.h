#include <graphics.h>
#ifndef FENETRES_H
#define FENETRES_H


class fenetres
{
    public:
        int x,y;
        fenetres(){
            this->x=400;
            this->y=400;
        }
        void ouvrir_graphique(void){ //n�cessaire avant de commencer du graphique.

            initwindow(800,800,"Bon Homme");
        }
        void fermer_graphique(void){ //a appeler avant de quitter le programme.
            closegraph(ALL_WINDOWS);
        }
        int get_couleur_fond(void){ //nous dit quelle est la couleur du fond.
            return getbkcolor();
        }
        int get_x_max(void){ //nous dit quel est le X du coin inf�rieur droit de la fenetre.
            return getmaxx();
        }
        int get_y_max(void){ //nous dit quel est le Y du coin sup�rieur gauche.
            return getmaxy();
        }
        int get_couleur(int x, int y){ // nous dit quelle est la couleur actuelle du pt (x, y).
            return getpixel(x,y);
        }
        void allume(int x, int y,int c){ // allume le pt (x, y) dans la Couleur c.
            putpixel(x,y,c);
        }


};



#endif // FENETRES_H
