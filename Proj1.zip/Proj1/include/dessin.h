#ifndef DESSIN_H
#define DESSIN_H
#include "figure.h"


class dessin
{
    public:
        int nb;
        figure tab [100];

        dessin( int nb){
            this->nb=nb;
        }

        void deplacer(int x, int y){//deplacement bon homme.
          for (int i=0;i<this->nb;i++) {
                this->tab[i].deplacer(x,y);

       }
          }

};

#endif // DESSIN_H
