#include <CL/cl.h>
#include<stdio.h>
#include<conio.h>
#include<graphics.h>
#include<dos.h>
#include <iostream>
#include "fenetres.h"
#include "figure.h"
#include "dessin.h"
#include <cmath>


using namespace std;
main()
{
    fenetres f;
    int x,y;
    f.ouvrir_graphique();
    x=f.get_x_max()/2;
    y=f.get_y_max()/2;
    cout <<x<<","<<y;
    f.allume(x+50,y+50,WHITE);

    figure dh;
    dh.set_droite(100,200,150,0,15);
    dh.dessiner();

    figure rec;
    rec.set_rectangle(100,200,150,100,15);
    rec.dessiner();

    figure crx;
    crx.set_croix(100,200,150,190,15);
    crx.dessiner();

    figure tri;
    tri.set_triangle(120,130,100,180,13);
    tri.dessiner();

    tri.deplacer(200,200);

    delay(1000);
    cleardevice();
    delay(1000);

    figure tete;
    tete.set_cercle((f.get_x_max()-80),f.get_y_max()/2,40,15);
    tete.dessiner();

    figure corps;
    corps.set_rectangle((f.get_x_max()-80),(f.get_y_max()/2)+70,40,100,15);
    corps.dessiner();

    figure jambeD;
    jambeD.set_droite((f.get_x_max()-80)+10,(f.get_y_max()/2)+145,0,50,15);
    jambeD.dessiner();

    figure jambeG;
    jambeG.set_droite((f.get_x_max()-80)-10,(f.get_y_max()/2)+145,0,50,15);
    jambeG.dessiner();

    figure brasD;
    brasD.set_droite((f.get_x_max()-80)+40,(f.get_y_max()/2)+50,40,20,15);
    brasD.dessiner();


    figure brasG;
    brasG.set_droite((f.get_x_max()-80)-40,(f.get_y_max()/2)+50,40,-20,15);
    brasG.dessiner();

    dessin bonHomme(6);
    bonHomme.tab[0]=tete;
    bonHomme.tab[1]=corps;
    bonHomme.tab[2]=jambeD;
    bonHomme.tab[3]=jambeG;
    bonHomme.tab[4]=brasD;
    bonHomme.tab[5]= brasG;

    delay(2000);

    double nvX, nvY, angle;
    double rayon =200;
    const double PI = acos(-1.0);
    nvX = rayon;
    nvY= 0.0;
    angle = 0.0;


    for (int i = 0; i < 360; i++) { //d�placer le bonHomme dans un trajectoire circulaire
        int oldX=nvX,oldY=nvY;
        angle = i * PI / 180.0;
        //nouvelles dimensions
        nvX = int(rayon * cos(angle));
        nvY= int(rayon* sin(angle));
        //deplacement du bonHomme
        bonHomme.deplacer(nvX-oldX,nvY-oldY);

        delay(50);
    }



    for(int i=0;i<600;i++){ //d�placer le bonHomme dans un trajectoire inclinee
        bonHomme.deplacer(-1,-1);
	    delay(10);
    }

    delay(2000);





   // f.fermer_graphique();

}
